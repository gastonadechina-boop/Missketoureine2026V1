import AppRouter from './routes/AppRouter';
import { ToastContainer } from './components/Toast';
import './App.css';

function App() {
  return (
    <>
      <AppRouter />
      <ToastContainer />
    </>
  );
}

export default App;
