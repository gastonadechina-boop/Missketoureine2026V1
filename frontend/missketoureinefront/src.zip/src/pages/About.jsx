import { motion } from 'framer-motion';
import './About.css';

const About = () => {
  const values = [
    {
      icon: '🎯',
      title: 'Excellence',
      description: 'Promouvoir l\'excellence académique et personnelle des étudiants',
    },
    {
      icon: '✨',
      title: 'Élégance',
      description: 'Célébrer la beauté, le charme et le raffinement',
    },
    {
      icon: '🌟',
      title: 'Talent',
      description: 'Mettre en valeur les talents multiples de notre jeunesse',
    },
    {
      icon: '🤝',
      title: 'Intégrité',
      description: 'Garantir un processus de vote transparent et équitable',
    },
  ];

  return (
    <div className="about-page">
      {/* Hero Section */}
      <section className="about-hero">
        <div className="container">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
          >
            
            <h1 className="about-hero-title">À Propos du Concours</h1>
            <p className="about-hero-subtitle">
              Une célébration de l'excellence universitaire béninoise
            </p>
            
          </motion.div>
        </div>
      </section>

      {/* Mission Section */}
      <section className="about-mission section">
        <div className="container">
          <motion.div
            className="mission-content"
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
          >
            <h2 className="section-title">Notre Mission</h2>
            <div className="section-divider"></div>
            <p className="mission-text">
              Le concours <strong>Miss & Mister University Bénin</strong> a pour mission de 
              célébrer et promouvoir l'excellence, l'élégance et le talent de la jeunesse 
              universitaire béninoise. Nous offrons une plateforme moderne et sécurisée permettant 
              à tous de participer activement à l'élection de leurs représentants.
            </p>
            <p className="mission-text">
              À travers ce concours, nous visons à encourager le développement personnel, 
              l'engagement communautaire et la représentation positive de nos universités 
              sur la scène nationale et internationale.
            </p>
          </motion.div>
        </div>
      </section>

      {/* Values Section */}
      <section className="about-values section">
        <div className="container">
          <motion.div
            className="section-header"
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
          >
            <h2 className="section-title">Nos Valeurs</h2>
            <div className="section-divider"></div>
          </motion.div>

          <div className="values-grid">
            {values.map((value, index) => (
              <motion.div
                key={index}
                className="value-card"
                initial={{ opacity: 0, scale: 0.8 }}
                whileInView={{ opacity: 1, scale: 1 }}
                viewport={{ once: true }}
                transition={{ duration: 0.5, delay: index * 0.1 }}
                whileHover={{ y: -10 }}
              >
                <div className="value-icon">{value.icon}</div>
                <h3 className="value-title">{value.title}</h3>
                <p className="value-description">{value.description}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* History Section */}
      <section className="about-history section">
        <div className="container">
          <motion.div
            className="history-content"
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
          >
            <h2 className="section-title">Notre Histoire</h2>
            <div className="section-divider"></div>
            <p className="history-text">
              Lancé en 2020, le concours Miss & Mister University Bénin est devenu 
              un événement incontournable du calendrier universitaire béninois. Chaque année, 
              des centaines d'étudiants talentueux participent, représentant fièrement leurs 
              universités respectives.
            </p>
            <p className="history-text">
              En 2026, nous franchissons une nouvelle étape avec la digitalisation complète 
              du processus de vote, rendant le concours plus accessible, transparent et 
              sécurisé que jamais.
            </p>
          </motion.div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="about-cta section">
        <div className="container">
          <motion.div
            className="cta-box"
            initial={{ opacity: 0, scale: 0.9 }}
            whileInView={{ opacity: 1, scale: 1 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
          >
            <h2>Rejoignez l'Aventure</h2>
            <p>Participez au vote et soutenez vos candidats préférés</p>
            <motion.button
              className="btn-primary"
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
            >
              Commencer à voter
            </motion.button>
          </motion.div>
        </div>
      </section>
    </div>
  );
};

export default About;
