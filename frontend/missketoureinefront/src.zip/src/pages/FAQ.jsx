import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import './FAQ.css';

const FAQ = () => {
  const [openIndex, setOpenIndex] = useState(null);

  const faqs = [
    {
      question: 'Comment puis-je voter ?',
      answer: 'Créez un compte, choisissez votre candidat préféré et effectuez le paiement via Mobile Money.'
    },
    {
      question: 'Combien coûte un vote ?',
      answer: 'Le prix d\'un vote sera communiqué lors du lancement officiel du concours.'
    },
    {
      question: 'Puis-je voter plusieurs fois ?',
      answer: 'Oui, vous pouvez voter plusieurs fois, mais des limitations quotidiennes peuvent s\'appliquer.'
    },
    {
      question: 'Quels moyens de paiement sont acceptés ?',
      answer: 'Nous acceptons MTN Mobile Money, Moov Money et Flooz.'
    },
    {
      question: 'Comment savoir si mon vote a été comptabilisé ?',
      answer: 'Vous recevrez une confirmation par SMS et email après chaque vote réussi.'
    },
  ];

  return (
    <div className="faq-page">
      <section className="faq-hero">
        <div className="container">
          <motion.h1
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
          >
            Questions Fréquentes
          </motion.h1>
          <motion.p
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.2 }}
          >
            Trouvez les réponses à vos questions
          </motion.p>
        </div>
      </section>

      <section className="faq-content section">
        <div className="container">
          <div className="faq-list">
            {faqs.map((faq, index) => (
              <motion.div
                key={index}
                className="faq-item"
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: index * 0.1 }}
              >
                <button
                  className="faq-question"
                  onClick={() => setOpenIndex(openIndex === index ? null : index)}
                >
                  <span>{faq.question}</span>
                  <span className={`faq-icon ${openIndex === index ? 'open' : ''}`}>
                    ▼
                  </span>
                </button>
                <AnimatePresence>
                  {openIndex === index && (
                    <motion.div
                      className="faq-answer"
                      initial={{ height: 0, opacity: 0 }}
                      animate={{ height: 'auto', opacity: 1 }}
                      exit={{ height: 0, opacity: 0 }}
                      transition={{ duration: 0.3 }}
                    >
                      <p>{faq.answer}</p>
                    </motion.div>
                  )}
                </AnimatePresence>
              </motion.div>
            ))}
          </div>
        </div>
      </section>
    </div>
  );
};

export default FAQ;
