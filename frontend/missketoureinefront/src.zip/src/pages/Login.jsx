import { useState } from 'react';
import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import './Login.css';

const Login = () => {
  const [formData, setFormData] = useState({ email: '', password: '' });

  const handleSubmit = (e) => {
    e.preventDefault();
    console.log('Login:', formData);
  };

  return (
    <div className="login-page">
      <div className="login-container">
        <motion.div
          className="login-box"
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
        >
          <h1>Connexion</h1>
          <p>Connectez-vous pour voter</p>

          <form onSubmit={handleSubmit}>
            <div className="form-group">
              <label>Email</label>
              <input
                type="email"
                value={formData.email}
                onChange={(e) => setFormData({...formData, email: e.target.value})}
                required
              />
            </div>

            <div className="form-group">
              <label>Mot de passe</label>
              <input
                type="password"
                value={formData.password}
                onChange={(e) => setFormData({...formData, password: e.target.value})}
                required
              />
            </div>
                <div className="form-group">
            <button type="submit" className="btn-primary">
              <svg width="20" height="20" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" style={{marginRight: '8px'}}>
                <circle cx="12" cy="12" r="2" fill="#61DAFB"/>
                <circle cx="12" cy="12" r="5" stroke="#61DAFB" strokeWidth="2" fill="none"/>
                <circle cx="12" cy="12" r="9" stroke="#61DAFB" strokeWidth="2" fill="none"/>
                <path d="M12 2C13.1 2 14 2.9 14 4V6.1C15.2 6.6 16.2 7.4 16.9 8.4L18.7 7.6C19.1 7.4 19.6 7.7 19.8 8.1C20 8.5 19.7 9 19.3 9.2L17.5 10C17.8 10.7 18 11.3 18 12C18 12.7 17.8 13.3 17.5 14L19.3 14.8C19.7 15 20 15.5 19.8 15.9C19.6 16.3 19.1 16.6 18.7 16.4L16.9 15.6C16.2 16.6 15.2 17.4 14 17.9V20C14 21.1 13.1 22 12 22C10.9 22 10 21.1 10 20V17.9C8.8 17.4 7.8 16.6 7.1 15.6L5.3 16.4C4.9 16.6 4.4 16.3 4.2 15.9C4 15.5 4.3 15 4.7 14.8L6.5 14C6.2 13.3 6 12.7 6 12C6 11.3 6.2 10.7 6.5 10L4.7 9.2C4.3 9 4 8.5 4.2 8.1C4.4 7.7 4.9 7.4 5.3 7.6L7.1 8.4C7.8 7.4 8.8 6.6 10 6.1V4C10 2.9 10.9 2 12 2Z" fill="#61DAFB"/>
              </svg>
              Se connecter
            </button>
            </div>
          </form>

          <p className="auth-link">
            Pas encore de compte ? <Link to="/register">S'inscrire</Link>
          </p>
        </motion.div>
      </div>
    </div>
  );
};

export default Login;
