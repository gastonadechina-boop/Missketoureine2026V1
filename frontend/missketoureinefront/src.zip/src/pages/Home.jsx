import { motion } from 'framer-motion';
import { Link } from 'react-router-dom';
import CandidateCard from '../components/CandidateCard';
import videoAnime from '../assets/videoanime.mp4';
import './Home.css';

const Home = () => {
  // Données de démonstration pour les candidats vedettes
  const featuredCandidates = [
    {
      id: 1,
      name: 'Sophie AKAKPO',
      category: 'Miss',
      university: 'Université d\'Abomey-Calavi',
      photo: '/placeholder-miss.jpg',
      votes: 1250,
      description: 'Étudiante en droit, passionnée par la justice sociale et l\'égalité.',
    },
    {
      id: 2,
      name: 'Jean-Marc DOSSOU',
      category: 'Mister',
      university: 'Université de Parakou',
      photo: '/placeholder-mister.jpg',
      votes: 980,
      description: 'Étudiant en médecine, engagé pour la santé communautaire.',
    },
    {
      id: 3,
      name: 'Marie KOUDJO',
      category: 'Miss',
      university: 'Université Nationale du Bénin',
      photo: '/placeholder-miss2.jpg',
      votes: 1450,
      description: 'Étudiante en sciences politiques, militante pour l\'éducation des jeunes filles.',
    },
  ];

  const stats = [
    { icon: '👥', value: '50+', label: 'Candidats' },
    { icon: '🎓', value: '10+', label: 'Universités' },
    { icon: '⭐', value: '10K+', label: 'Votes' },
    { icon: '🏆', value: '2', label: 'Gagnants' },
  ];

  return (
    <div className="home">
      {/* Section Hero avec vidéo */}
      <section className="hero">
       

        <div className="hero-content">
          <motion.div
            className="hero-text"
            initial={{ opacity: 0, y: 50 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
          >
            <motion.h1
              className="hero-title"
              initial={{ opacity: 0, scale: 0.8 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ duration: 0.8, delay: 0.2 }}
            >
              Miss & Mister
              <span className="hero-title-highlight"> University Bénin</span>
            </motion.h1>

            <motion.p
              className="hero-subtitle"
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8, delay: 0.4 }}
            >
              Célébrons l'excellence, l'élégance et le talent de la jeunesse universitaire béninoise
            </motion.p>

            <motion.div
              className="hero-buttons"
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8, delay: 0.6 }}
            >
              <Link to="/candidates">
                <motion.button
                  className="btn-primary hero-btn"
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                >
                  <span>🗳️</span> Voter maintenant
                </motion.button>
              </Link>
              <Link to="/about">
                <motion.button
                  className="btn-secondary hero-btn"
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                >
                  <span>ℹ️</span> En savoir plus
                </motion.button>
              </Link>
            </motion.div>
          </motion.div>

          {/* Scroll indicator */}
          <motion.div
            className="scroll-indicator"
            animate={{ y: [0, 10, 0] }}
            transition={{ duration: 1.5, repeat: Infinity }}
          >
            <span>⬇️</span>
          </motion.div>
        </div>
      </section>

      {/* Section Statistiques */}
      <section className="stats-section">
        <div className="container">
          <div className="stats-grid">
            {stats.map((stat, index) => (
              <motion.div
                key={index}
                className="stat-card"
                initial={{ opacity: 0, scale: 0.8 }}
                whileInView={{ opacity: 1, scale: 1 }}
                viewport={{ once: true }}
                transition={{ duration: 0.5, delay: index * 0.1 }}
                whileHover={{ y: -10 }}
              >
                <motion.div
                  className="stat-icon"
                  animate={{ rotate: [0, 10, -10, 0] }}
                  transition={{ duration: 2, repeat: Infinity, repeatDelay: 3 }}
                >
                  {stat.icon}
                </motion.div>
                <h3 className="stat-value">{stat.value}</h3>
                <p className="stat-label">{stat.label}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Section À propos */}
      <section className="about-section section">
        <div className="container">
          <motion.div
            className="section-header"
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
          >
            <h2 className="section-title">À Propos du Concours</h2>
            <div className="section-divider"></div>
          </motion.div>

          <motion.div
            className="about-content"
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6, delay: 0.2 }}
          >
            <p className="about-text">
              Le concours <strong>Miss & Mister University Bénin</strong> est une célébration 
              de l'excellence académique, de l'élégance et du talent de la jeunesse universitaire 
              béninoise. Cette plateforme digitale permet à tous de participer au vote de manière 
              sécurisée et transparente.
            </p>
            <Link to="/about">
              <motion.button
                className="btn-primary"
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
              >
                Découvrir plus
              </motion.button>
            </Link>
          </motion.div>
        </div>
      </section>

      {/* Section Candidats vedettes */}
      <section className="featured-section section">
        <div className="container">
          <motion.div
            className="section-header"
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
          >
            <h2 className="section-title">Candidats Vedettes</h2>
            <div className="section-divider"></div>
            <p className="section-subtitle">
              Découvrez quelques-uns de nos candidats exceptionnels
            </p>
          </motion.div>

          <div className="candidates-grid">
            {featuredCandidates.map((candidate, index) => (
              <motion.div
                key={candidate.id}
                initial={{ opacity: 0, y: 50 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.5, delay: index * 0.2 }}
              >
                <CandidateCard candidate={candidate} />
              </motion.div>
            ))}
          </div>

          <motion.div
            className="featured-cta"
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
          >
            <Link to="/candidates">
              <motion.button
                className="btn-primary"
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
              >
                Voir tous les candidats
              </motion.button>
            </Link>
          </motion.div>
        </div>
      </section>

      {/* Section Comment voter */}
      <section className="how-to-vote-section section">
        <div className="container">
          <motion.div
            className="section-header"
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
          >
            <h2 className="section-title">Comment Voter ?</h2>
            <div className="section-divider"></div>
          </motion.div>

          <div className="steps-grid">
            {[
              { icon: '📝', title: 'Créez un compte', description: 'Inscrivez-vous gratuitement avec votre email ou numéro de téléphone' },
              { icon: '👤', title: 'Choisissez votre candidat', description: 'Parcourez les profils et découvrez les candidats' },
              { icon: '💳', title: 'Effectuez le paiement', description: 'Payez via Mobile Money (MTN, Moov, Flooz)' },
              { icon: '✅', title: 'Confirmez votre vote', description: 'Recevez une confirmation par SMS ou email' },
            ].map((step, index) => (
              <motion.div
                key={index}
                className="step-card"
                initial={{ opacity: 0, scale: 0.8 }}
                whileInView={{ opacity: 1, scale: 1 }}
                viewport={{ once: true }}
                transition={{ duration: 0.5, delay: index * 0.1 }}
                whileHover={{ y: -10 }}
              >
                <div className="step-number">{index + 1}</div>
                <div className="step-icon">{step.icon}</div>
                <h3 className="step-title">{step.title}</h3>
                <p className="step-description">{step.description}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Section CTA finale */}
      <section className="cta-section">
        <div className="container">
          <motion.div
            className="cta-content"
            initial={{ opacity: 0, scale: 0.9 }}
            whileInView={{ opacity: 1, scale: 1 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
          >
            <h2 className="cta-title">Prêt à Voter ?</h2>
            <p className="cta-text">
              Soutenez votre candidat préféré et participez à l'élection de 
              Miss & Mister University Bénin 2026
            </p>
            <Link to="/register">
              <motion.button
                className="btn-primary cta-btn"
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
              >
                <span>🚀</span> Commencer maintenant
              </motion.button>
            </Link>
          </motion.div>
        </div>
      </section>
    </div>
  );
};

export default Home;
