import { useState } from 'react';
import { motion } from 'framer-motion';
import CandidateCard from '../components/CandidateCard';
import './Candidates.css';

const Candidates = () => {
  const [filter, setFilter] = useState('all');
  const [searchQuery, setSearchQuery] = useState('');

  // Données de démonstration
  const mockCandidates = [
    { id: 1, name: 'Sophie AKAKPO', category: 'Miss', university: 'UAC', photo: '', votes: 1250 },
    { id: 2, name: 'Jean-Marc DOSSOU', category: 'Mister', university: 'UP', photo: '', votes: 980 },
    { id: 3, name: 'Marie KOUDJO', category: 'Miss', university: 'UNB', photo: '', votes: 1450 },
    { id: 4, name: 'David HOUNGBO', category: 'Mister', university: 'UAC', photo: '', votes: 1100 },
    { id: 5, name: 'Aïcha SANNI', category: 'Miss', university: 'UP', photo: '', votes: 1350 },
    { id: 6, name: 'Patrick ADJOVI', category: 'Mister', university: 'UNB', photo: '', votes: 950 },
  ];

  const filteredCandidates = mockCandidates.filter(candidate => {
    const matchesFilter = filter === 'all' || candidate.category.toLowerCase() === filter;
    const matchesSearch = candidate.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
                         candidate.university.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesFilter && matchesSearch;
  });

  return (
    <div className="candidates-page">
      <section className="candidates-hero">
        <div className="container">
          <motion.h1
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
          >
            Nos Candidats
          </motion.h1>
          <motion.p
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.2 }}
          >
            Découvrez tous les candidats et votez pour vos préférés
          </motion.p>
        </div>
      </section>

      <section className="candidates-filters section">
        <div className="container">
          <div className="filters-wrapper">
            <div className="filter-buttons">
              <motion.button
                className={`filter-btn ${filter === 'all' ? 'active' : ''}`}
                onClick={() => setFilter('all')}
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
              >
                Tous
              </motion.button>
              <motion.button
                className={`filter-btn ${filter === 'miss' ? 'active' : ''}`}
                onClick={() => setFilter('miss')}
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
              >
                👑 Miss
              </motion.button>
              <motion.button
                className={`filter-btn ${filter === 'mister' ? 'active' : ''}`}
                onClick={() => setFilter('mister')}
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
              >
                🤴 Mister
              </motion.button>
            </div>

            <div className="search-box">
              <input
                type="text"
                placeholder="Rechercher un candidat..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="search-input"
              />
              <span className="search-icon">🔍</span>
            </div>
          </div>
        </div>
      </section>

      <section className="candidates-grid-section section">
        <div className="container">
          <div className="candidates-grid">
            {filteredCandidates.map((candidate, index) => (
              <motion.div
                key={candidate.id}
                initial={{ opacity: 0, y: 50 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5, delay: index * 0.1 }}
              >
                <CandidateCard candidate={candidate} />
              </motion.div>
            ))}
          </div>

          {filteredCandidates.length === 0 && (
            <motion.div
              className="no-results"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
            >
              <p>Aucun candidat trouvé</p>
            </motion.div>
          )}
        </div>
      </section>
    </div>
  );
};

export default Candidates;
