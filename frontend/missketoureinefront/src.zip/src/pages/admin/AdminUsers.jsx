import { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import DataTable from '../../components/DataTable';
import './AdminUsers.css';

// Données mockées des utilisateurs
const mockUsers = [
  { id: 1, name: 'Jean Dupont', email: 'jean@email.com', votes: 5, status: 'active', registered: '2026-01-15' },
  { id: 2, name: 'Sophie Martin', email: 'sophie@email.com', votes: 3, status: 'active', registered: '2026-01-20' },
  { id: 3, name: 'Marc Bernard', email: 'marc@email.com', votes: 8, status: 'active', registered: '2026-02-01' },
  { id: 4, name: 'Emma Petit', email: 'emma@email.com', votes: 2, status: 'suspended', registered: '2026-02-10' },
  { id: 5, name: 'Louis Moreau', email: 'louis@email.com', votes: 6, status: 'active', registered: '2026-02-15' }
];

const AdminUsers = () => {
  const [users, setUsers] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    // Simulation de chargement des données
    setTimeout(() => {
      setUsers(mockUsers);
      setLoading(false);
    }, 500);
  }, []);

  const handleStatusToggle = (user) => {
    setUsers(users.map(u =>
      u.id === user.id
        ? { ...u, status: u.status === 'active' ? 'suspended' : 'active' }
        : u
    ));

    // Simulation d'appel API
    if (window.showToast) {
      window.showToast(
        `Statut de ${user.name} mis à jour`,
        'success'
      );
    }
  };

  const handleDelete = (user) => {
    if (window.confirm(`Êtes-vous sûr de vouloir supprimer l'utilisateur ${user.name} ?`)) {
      setUsers(users.filter(u => u.id !== user.id));

      if (window.showToast) {
        window.showToast(
          `Utilisateur ${user.name} supprimé`,
          'success'
        );
      }
    }
  };

  const columns = [
    {
      key: 'name',
      label: 'Nom',
      sortable: true
    },
    {
      key: 'email',
      label: 'Email',
      sortable: true
    },
    {
      key: 'votes',
      label: 'Votes',
      sortable: true,
      render: (value) => `${value} vote${value > 1 ? 's' : ''}`
    },
    {
      key: 'status',
      label: 'Statut',
      sortable: true,
      render: (value) => (
        <span className={`status-badge ${value}`}>
          {value === 'active' ? 'Actif' : value === 'suspended' ? 'Suspendu' : value}
        </span>
      )
    },
    {
      key: 'registered',
      label: 'Inscription',
      sortable: true,
      render: (value) => new Date(value).toLocaleDateString('fr-FR')
    }
  ];

  const actions = [
    {
      label: 'Modifier statut',
      icon: '🔄',
      onClick: handleStatusToggle
    },
    {
      label: 'Supprimer',
      icon: '🗑️',
      className: 'delete',
      onClick: handleDelete
    }
  ];

  return (
    <div className="admin-users">
      {/* Header avec bouton ajouter */}
      <div className="page-header">
        <div className="page-title">
          <h1>Gestion des Utilisateurs</h1>
          <p>Gérer les comptes utilisateurs et leurs permissions</p>
        </div>
        <motion.button
          className="add-user-btn"
          whileHover={{ scale: 1.05 }}
          whileTap={{ scale: 0.95 }}
        >
          <svg width="20" height="20" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" style={{marginRight: '8px'}}>
            <path d="M12 5V19M5 12H19" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
          </svg>
          Ajouter Utilisateur
        </motion.button>
      </div>

      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
      >
        <DataTable
          columns={columns}
          data={users}
          actions={actions}
          searchable={true}
          sortable={true}
          pagination={true}
          pageSize={10}
        />
      </motion.div>
    </div>
  );
};

export default AdminUsers;