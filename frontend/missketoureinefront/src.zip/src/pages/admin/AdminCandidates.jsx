import { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import './AdminCandidates.css';

// Données mockées des candidats
const mockCandidates = [
  {
    id: 1,
    name: 'Marie Dupont',
    age: 25,
    category: 'Miss',
    description: 'Passionnée par la mode et l\'art...',
    votes: 145,
    status: 'active',
    image: '/api/placeholder/150/200'
  },
  {
    id: 2,
    name: 'Pierre Martin',
    age: 28,
    category: 'Mister',
    description: 'Sportif et entrepreneur...',
    votes: 132,
    status: 'active',
    image: '/api/placeholder/150/200'
  },
  {
    id: 3,
    name: 'Alice Bernard',
    age: 23,
    category: 'Miss',
    description: 'Étudiante en droit...',
    votes: 98,
    status: 'active',
    image: '/api/placeholder/150/200'
  },
  {
    id: 4,
    name: 'Lucas Petit',
    age: 26,
    category: 'Mister',
    description: 'Musicien et voyageur...',
    votes: 87,
    status: 'inactive',
    image: '/api/placeholder/150/200'
  }
];

const AdminCandidates = () => {
  const [candidates, setCandidates] = useState([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [filterCategory, setFilterCategory] = useState('all');
  const [filterStatus, setFilterStatus] = useState('all');

  useEffect(() => {
    // Simulation de chargement des données
    setTimeout(() => {
      setCandidates(mockCandidates);
    }, 500);
  }, []);

  const filteredCandidates = candidates.filter(candidate => {
    const matchesSearch = candidate.name.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesCategory = filterCategory === 'all' || candidate.category.toLowerCase() === filterCategory;
    const matchesStatus = filterStatus === 'all' || candidate.status === filterStatus;
    return matchesSearch && matchesCategory && matchesStatus;
  });

  const handleStatusToggle = (id) => {
    setCandidates(candidates.map(candidate =>
      candidate.id === id
        ? { ...candidate, status: candidate.status === 'active' ? 'inactive' : 'active' }
        : candidate
    ));
  };

  const handleDelete = (id) => {
    if (window.confirm('Êtes-vous sûr de vouloir supprimer ce candidat ?')) {
      setCandidates(candidates.filter(candidate => candidate.id !== id));
    }
  };

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.1
      }
    }
  };

  const itemVariants = {
    hidden: { y: 20, opacity: 0 },
    visible: {
      y: 0,
      opacity: 1,
      transition: {
        type: "spring",
        stiffness: 100
      }
    }
  };

  return (
    <div className="admin-candidates">
      {/* Header avec bouton ajouter */}
      <div className="page-header">
        <div className="page-title">
          <h1>Gestion des Candidats</h1>
          <p>Ajouter, modifier et gérer les candidats du concours</p>
        </div>
        <motion.button
          className="add-candidate-btn"
          whileHover={{ scale: 1.05 }}
          whileTap={{ scale: 0.95 }}
        >
          <svg width="20" height="20" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" style={{marginRight: '8px'}}>
            <path d="M12 5V19M5 12H19" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
          </svg>
          Ajouter Candidat
        </motion.button>
      </div>

      {/* Filters */}
      <motion.div
        className="filters-section"
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.3 }}
      >
        <div className="filters-grid">
          <div className="filter-group">
            <label>Rechercher</label>
            <input
              type="text"
              placeholder="Nom du candidat..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
            />
          </div>
          <div className="filter-group">
            <label>Catégorie</label>
            <select value={filterCategory} onChange={(e) => setFilterCategory(e.target.value)}>
              <option value="all">Toutes</option>
              <option value="miss">Miss</option>
              <option value="mister">Mister</option>
            </select>
          </div>
          <div className="filter-group">
            <label>Statut</label>
            <select value={filterStatus} onChange={(e) => setFilterStatus(e.target.value)}>
              <option value="all">Tous</option>
              <option value="active">Actif</option>
              <option value="inactive">Inactif</option>
            </select>
          </div>
        </div>
      </motion.div>

      {/* Candidates Grid */}
      <motion.div
        className="candidates-grid"
        variants={containerVariants}
        initial="hidden"
        animate="visible"
      >
        {filteredCandidates.map((candidate) => (
          <motion.div
            key={candidate.id}
            className="candidate-card"
            variants={itemVariants}
            whileHover={{ scale: 1.02 }}
            transition={{ type: "spring", stiffness: 300 }}
          >
            <div className="candidate-image">
              <img src={candidate.image} alt={candidate.name} />
              <div className={`status-badge ${candidate.status}`}>
                {candidate.status === 'active' ? 'Actif' : 'Inactif'}
              </div>
            </div>
            <div className="candidate-info">
              <h3>{candidate.name}</h3>
              <p className="candidate-details">
                {candidate.age} ans • {candidate.category}
              </p>
              <p className="candidate-description">{candidate.description}</p>
              <div className="candidate-stats">
                <span className="votes-count">🗳️ {candidate.votes} votes</span>
              </div>
            </div>
            <div className="candidate-actions">
              <motion.button
                className="action-btn edit"
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
              >
                ✏️ Modifier
              </motion.button>
              <motion.button
                className={`action-btn status ${candidate.status}`}
                onClick={() => handleStatusToggle(candidate.id)}
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
              >
                {candidate.status === 'active' ? '🚫 Désactiver' : '✅ Activer'}
              </motion.button>
              <motion.button
                className="action-btn delete"
                onClick={() => handleDelete(candidate.id)}
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
              >
                🗑️ Supprimer
              </motion.button>
            </div>
          </motion.div>
        ))}
      </motion.div>
    </div>
  );
};

export default AdminCandidates;