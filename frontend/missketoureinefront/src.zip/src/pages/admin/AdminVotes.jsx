import { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import DataTable from '../../components/DataTable';
import './AdminVotes.css';

// Données mockées des votes
const mockVotes = [
  { id: 1, candidate: 'Marie Dupont', voter: 'jean@email.com', timestamp: '2026-03-13 14:30:00', ip: '192.168.1.1' },
  { id: 2, candidate: 'Pierre Martin', voter: 'sophie@email.com', timestamp: '2026-03-13 14:25:00', ip: '192.168.1.2' },
  { id: 3, candidate: 'Alice Bernard', voter: 'marc@email.com', timestamp: '2026-03-13 14:20:00', ip: '192.168.1.3' },
  { id: 4, candidate: 'Lucas Petit', voter: 'emma@email.com', timestamp: '2026-03-13 14:15:00', ip: '192.168.1.4' },
  { id: 5, candidate: 'Chloé Moreau', voter: 'louis@email.com', timestamp: '2026-03-13 14:10:00', ip: '192.168.1.5' }
];

const AdminVotes = () => {
  const [votes, setVotes] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    // Simulation de chargement des données
    setTimeout(() => {
      setVotes(mockVotes);
      setLoading(false);
    }, 500);
  }, []);

  const handleDelete = (vote) => {
    if (window.confirm(`Êtes-vous sûr de vouloir supprimer ce vote de ${vote.voter} pour ${vote.candidate} ?`)) {
      setVotes(votes.filter(v => v.id !== vote.id));

      if (window.showToast) {
        window.showToast(
          'Vote supprimé avec succès',
          'success'
        );
      }
    }
  };

  const handleExport = () => {
    // Simulation d'export
    const csvContent = [
      ['ID', 'Candidat', 'Votant', 'Date/Heure', 'IP'],
      ...votes.map(vote => [vote.id, vote.candidate, vote.voter, vote.timestamp, vote.ip])
    ].map(row => row.join(',')).join('\n');

    const blob = new Blob([csvContent], { type: 'text/csv' });
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'votes-export.csv';
    a.click();
    window.URL.revokeObjectURL(url);

    if (window.showToast) {
      window.showToast(
        'Export des votes terminé',
        'success'
      );
    }
  };

  const columns = [
    {
      key: 'candidate',
      label: 'Candidat',
      sortable: true
    },
    {
      key: 'voter',
      label: 'Votant',
      sortable: true
    },
    {
      key: 'timestamp',
      label: 'Date/Heure',
      sortable: true,
      render: (value) => new Date(value).toLocaleString('fr-FR')
    },
    {
      key: 'ip',
      label: 'Adresse IP',
      sortable: false
    }
  ];

  const actions = [
    {
      label: 'Supprimer',
      icon: '🗑️',
      className: 'delete',
      onClick: handleDelete
    }
  ];

  return (
    <div className="admin-votes">
      {/* Header avec bouton export */}
      <div className="page-header">
        <div className="page-title">
          <h1>Gestion des Votes</h1>
          <p>Consulter et gérer tous les votes du concours</p>
        </div>
        <motion.button
          className="export-btn"
          onClick={handleExport}
          whileHover={{ scale: 1.05 }}
          whileTap={{ scale: 0.95 }}
        >
          <svg width="20" height="20" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" style={{marginRight: '8px'}}>
            <path d="M21 15V19C21 19.5304 20.7893 20.0391 20.4142 20.4142C20.0391 20.7893 19.5304 21 19 21H5C4.46957 21 3.96086 20.7893 3.58579 20.4142C3.21071 20.0391 3 19.5304 3 19V15" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
            <path d="M7 10L12 15L17 10" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
            <path d="M12 15V3" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
          </svg>
          Exporter CSV
        </motion.button>
      </div>

      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
      >
        <DataTable
          columns={columns}
          data={votes}
          actions={actions}
          searchable={true}
          sortable={true}
          pagination={true}
          pageSize={10}
        />
      </motion.div>
    </div>
  );
};

export default AdminVotes;