import { useState } from 'react';
import { motion } from 'framer-motion';
import './AdminSettings.css';

const AdminSettings = () => {
  const [settings, setSettings] = useState({
    contestStart: '2026-03-01',
    contestEnd: '2026-03-31',
    maxVotesPerUser: 1,
    votingEnabled: true,
    registrationEnabled: true,
    showResults: false,
    emailNotifications: true,
    maintenanceMode: false
  });

  const [loading, setLoading] = useState(false);

  const handleSave = async () => {
    setLoading(true);

    // Simulation de sauvegarde
    setTimeout(() => {
      setLoading(false);
      if (window.showToast) {
        window.showToast(
          'Paramètres sauvegardés avec succès',
          'success'
        );
      }
    }, 1000);
  };

  const handleInputChange = (e) => {
    const { name, value, type, checked } = e.target;
    setSettings(prev => ({
      ...prev,
      [name]: type === 'checkbox' ? checked : value
    }));
  };

  return (
    <div className="admin-settings">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
      >
        <div className="page-header">
          <div className="page-title">
            <h1>Paramètres du Système</h1>
            <p>Configurer les paramètres généraux du concours</p>
          </div>
        </div>

        <div className="settings-container">
          {/* Section Dates du concours */}
          <div className="settings-section">
            <h3>Dates du Concours</h3>
            <div className="form-grid">
              <div className="form-group">
                <label htmlFor="contestStart">Date de début</label>
                <input
                  type="date"
                  id="contestStart"
                  name="contestStart"
                  value={settings.contestStart}
                  onChange={handleInputChange}
                />
              </div>
              <div className="form-group">
                <label htmlFor="contestEnd">Date de fin</label>
                <input
                  type="date"
                  id="contestEnd"
                  name="contestEnd"
                  value={settings.contestEnd}
                  onChange={handleInputChange}
                />
              </div>
            </div>
          </div>

          {/* Section Règles de vote */}
          <div className="settings-section">
            <h3>Règles de Vote</h3>
            <div className="form-grid">
              <div className="form-group">
                <label htmlFor="maxVotesPerUser">Votes maximum par utilisateur</label>
                <input
                  type="number"
                  id="maxVotesPerUser"
                  name="maxVotesPerUser"
                  min="1"
                  max="10"
                  value={settings.maxVotesPerUser}
                  onChange={handleInputChange}
                />
              </div>
            </div>
          </div>

          {/* Section Fonctionnalités */}
          <div className="settings-section">
            <h3>Fonctionnalités</h3>
            <div className="checkbox-grid">
              <label className="checkbox-item">
                <input
                  type="checkbox"
                  name="votingEnabled"
                  checked={settings.votingEnabled}
                  onChange={handleInputChange}
                />
                <span className="checkmark"></span>
                Votes activés
              </label>

              <label className="checkbox-item">
                <input
                  type="checkbox"
                  name="registrationEnabled"
                  checked={settings.registrationEnabled}
                  onChange={handleInputChange}
                />
                <span className="checkmark"></span>
                Inscriptions activées
              </label>

              <label className="checkbox-item">
                <input
                  type="checkbox"
                  name="showResults"
                  checked={settings.showResults}
                  onChange={handleInputChange}
                />
                <span className="checkmark"></span>
                Afficher les résultats
              </label>

              <label className="checkbox-item">
                <input
                  type="checkbox"
                  name="emailNotifications"
                  checked={settings.emailNotifications}
                  onChange={handleInputChange}
                />
                <span className="checkmark"></span>
                Notifications par email
              </label>

              <label className="checkbox-item danger">
                <input
                  type="checkbox"
                  name="maintenanceMode"
                  checked={settings.maintenanceMode}
                  onChange={handleInputChange}
                />
                <span className="checkmark"></span>
                Mode maintenance
              </label>
            </div>
          </div>

          {/* Boutons d'action */}
          <div className="settings-actions">
            <motion.button
              className="save-btn"
              onClick={handleSave}
              disabled={loading}
              whileHover={{ scale: 1.02 }}
              whileTap={{ scale: 0.98 }}
            >
              {loading ? 'Sauvegarde...' : 'Sauvegarder les paramètres'}
            </motion.button>
          </div>
        </div>
      </motion.div>
    </div>
  );
};

export default AdminSettings;