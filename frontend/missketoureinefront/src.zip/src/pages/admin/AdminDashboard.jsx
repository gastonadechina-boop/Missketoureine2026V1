import { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import './AdminDashboard.css';

// Données mockées
const mockStats = {
  totalCandidates: 24,
  totalUsers: 1250,
  totalVotes: 3456,
  activeVotes: 892
};

const mockRecentVotes = [
  { id: 1, candidate: 'Marie Dupont', voter: 'jean@email.com', date: '2026-03-13 14:30' },
  { id: 2, candidate: 'Pierre Martin', voter: 'sophie@email.com', date: '2026-03-13 14:25' },
  { id: 3, candidate: 'Alice Bernard', voter: 'marc@email.com', date: '2026-03-13 14:20' },
  { id: 4, candidate: 'Lucas Petit', voter: 'emma@email.com', date: '2026-03-13 14:15' },
  { id: 5, candidate: 'Chloé Moreau', voter: 'louis@email.com', date: '2026-03-13 14:10' }
];

// Mock top candidates for chart
const topCandidates = [
  { name: 'Marie D.', votes: 892 },
  { name: 'Pierre M.', votes: 756 },
  { name: 'Alice B.', votes: 623 },
  { name: 'Lucas P.', votes: 589 },
  { name: 'Chloé M.', votes: 456 }
];

const AdminDashboard = () => {
  const [stats, setStats] = useState(mockStats);
  const [recentVotes, setRecentVotes] = useState(mockRecentVotes);

  useEffect(() => {
    // Simulation de chargement des données
    const timer = setTimeout(() => {
      setStats(mockStats);
      setRecentVotes(mockRecentVotes);
    }, 500);

    return () => clearTimeout(timer);
  }, []);

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.1
      }
    }
  };

  const itemVariants = {
    hidden: { y: 20, opacity: 0 },
    visible: {
      y: 0,
      opacity: 1,
      transition: {
        type: "spring",
        stiffness: 100
      }
    }
  };

  return (
    <div className="admin-dashboard">
      {/* Titre de la page */}
      <div className="page-header">
        <div className="page-title">
          <h1>Tableau de Bord</h1>
          <p>Aperçu général du concours Miss & Mister</p>
        </div>
      </div>

      {/* Stats Cards */}
      <motion.div
        className="stats-grid"
        variants={containerVariants}
        initial="hidden"
        animate="visible"
      >
        <motion.div className="stat-card" variants={itemVariants}>
          <div className="stat-icon">
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
              <circle cx="12" cy="12" r="2" fill="#61DAFB"/>
              <circle cx="12" cy="12" r="5" stroke="#61DAFB" strokeWidth="2" fill="none"/>
              <circle cx="12" cy="12" r="9" stroke="#61DAFB" strokeWidth="2" fill="none"/>
              <path d="M12 2C13.1 2 14 2.9 14 4V6.1C15.2 6.6 16.2 7.4 16.9 8.4L18.7 7.6C19.1 7.4 19.6 7.7 19.8 8.1C20 8.5 19.7 9 19.3 9.2L17.5 10C17.8 10.7 18 11.3 18 12C18 12.7 17.8 13.3 17.5 14L19.3 14.8C19.7 15 20 15.5 19.8 15.9C19.6 16.3 19.1 16.6 18.7 16.4L16.9 15.6C16.2 16.6 15.2 17.4 14 17.9V20C14 21.1 13.1 22 12 22C10.9 22 10 21.1 10 20V17.9C8.8 17.4 7.8 16.6 7.1 15.6L5.3 16.4C4.9 16.6 4.4 16.3 4.2 15.9C4 15.5 4.3 15 4.7 14.8L6.5 14C6.2 13.3 6 12.7 6 12C6 11.3 6.2 10.7 6.5 10L4.7 9.2C4.3 9 4 8.5 4.2 8.1C4.4 7.7 4.9 7.4 5.3 7.6L7.1 8.4C7.8 7.4 8.8 6.6 10 6.1V4C10 2.9 10.9 2 12 2Z" fill="#61DAFB"/>
            </svg>
          </div>
          <div className="stat-content">
            <h3>{stats.totalCandidates}</h3>
            <p>Candidats</p>
          </div>
        </motion.div>

        <motion.div className="stat-card" variants={itemVariants}>
          <div className="stat-icon">
            👥
          </div>
          <div className="stat-content">
            <h3>{stats.totalUsers.toLocaleString()}</h3>
            <p>Utilisateurs</p>
          </div>
        </motion.div>

        <motion.div className="stat-card" variants={itemVariants}>
          <div className="stat-icon">
            🗳️
          </div>
          <div className="stat-content">
            <h3>{stats.totalVotes.toLocaleString()}</h3>
            <p>Total Votes</p>
          </div>
        </motion.div>

        <motion.div className="stat-card" variants={itemVariants}>
          <div className="stat-icon">
            ⚡
          </div>
          <div className="stat-content">
            <h3>{stats.activeVotes.toLocaleString()}</h3>
            <p>Votes Actifs</p>
          </div>
        </motion.div>
      </motion.div>

      {/* Recent Votes */}
      <motion.div
        className="recent-votes-section"
        initial={{ opacity: 0, y: 50 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.6 }}
      >
        <h2>Votes Récents</h2>
        <motion.div
          className="recent-votes-list"
          variants={containerVariants}
          initial="hidden"
          animate="visible"
        >
          {recentVotes.map((vote, index) => (
            <motion.div
              key={vote.id}
              className="vote-item"
              variants={itemVariants}
              whileHover={{ scale: 1.02 }}
            >
              <div className="vote-info">
                <span className="candidate-name">{vote.candidate}</span>
                <span className="voter-email">{vote.voter}</span>
              </div>
              <div className="vote-time">
                {vote.date}
              </div>
            </motion.div>
          ))}
        </motion.div>
      </motion.div>
    </div>
  );
};

export default AdminDashboard;