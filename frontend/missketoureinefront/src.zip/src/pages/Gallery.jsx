import { motion } from 'framer-motion';
import './Gallery.css';

const Gallery = () => {
  const mockGallery = [
    { id: 1, type: 'image', url: '/gallery1.jpg', title: 'Édition 2024' },
    { id: 2, type: 'image', url: '/gallery2.jpg', title: 'Cérémonie' },
    { id: 3, type: 'image', url: '/gallery3.jpg', title: 'Gagnants 2023' },
    { id: 4, type: 'image', url: '/gallery4.jpg', title: 'Défilé' },
  ];

  return (
    <div className="gallery-page">
      <section className="gallery-hero">
        <div className="container">
          <motion.h1
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
          >
            Galerie
          </motion.h1>
          <motion.p
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.2 }}
          >
            Revivez les moments forts des éditions précédentes
          </motion.p>
        </div>
      </section>

      <section className="gallery-grid-section section">
        <div className="container">
          <div className="gallery-grid">
            {mockGallery.map((item, index) => (
              <motion.div
                key={item.id}
                className="gallery-item"
                initial={{ opacity: 0, scale: 0.9 }}
                whileInView={{ opacity: 1, scale: 1 }}
                viewport={{ once: true }}
                transition={{ delay: index * 0.1 }}
                whileHover={{ scale: 1.05 }}
              >
                <img src={item.url} alt={item.title} />
                <div className="gallery-overlay">
                  <h3>{item.title}</h3>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>
    </div>
  );
};

export default Gallery;
