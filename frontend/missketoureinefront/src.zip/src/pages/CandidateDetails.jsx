import { useParams } from 'react-router-dom';
import { motion } from 'framer-motion';
import VoteButton from '../components/VoteButton';
import './CandidateDetails.css';

const CandidateDetails = () => {
  const { id } = useParams();

  // Données de démonstration
  const candidate = {
    id,
    name: 'Sophie AKAKPO',
    category: 'Miss',
    university: 'Université d\'Abomey-Calavi',
    photo: '/placeholder.jpg',
    votes: 1250,
    age: 22,
    bio: 'Étudiante passionnée en droit, engagée pour la justice sociale et l\'égalité des chances.',
    hobbies: ['Lecture', 'Danse', 'Bénévolat'],
    achievements: ['Meilleure étudiante 2024', 'Présidente du club débat'],
  };

  return (
    <div className="candidate-details-page">
      <section className="details-hero">
        <div className="container">
          <div className="details-grid">
            <motion.div
              className="details-image"
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
            >
              <img src={candidate.photo} alt={candidate.name} />
              <div className={`category-badge ${candidate.category.toLowerCase()}`}>
                {candidate.category}
              </div>
            </motion.div>

            <motion.div
              className="details-info"
              initial={{ opacity: 0, x: 30 }}
              animate={{ opacity: 1, x: 0 }}
            >
              <h1>{candidate.name}</h1>
              <p className="university">🎓 {candidate.university}</p>
              <p className="age">🎂 {candidate.age} ans</p>
              <p className="votes">⭐ {candidate.votes.toLocaleString()} votes</p>
              
              <div className="bio-section">
                <h2>Biographie</h2>
                <p>{candidate.bio}</p>
              </div>

              <div className="hobbies-section">
                <h3>Centres d'intérêt</h3>
                <div className="tags">
                  {candidate.hobbies.map((hobby, i) => (
                    <span key={i} className="tag">{hobby}</span>
                  ))}
                </div>
              </div>

              <div className="achievements-section">
                <h3>Réalisations</h3>
                <ul>
                  {candidate.achievements.map((achievement, i) => (
                    <li key={i}>{achievement}</li>
                  ))}
                </ul>
              </div>

              <VoteButton
                candidateId={candidate.id}
                candidateName={candidate.name}
                onVote={() => console.log('Vote')}
              />
            </motion.div>
          </div>
        </div>
      </section>
    </div>
  );
};

export default CandidateDetails;
