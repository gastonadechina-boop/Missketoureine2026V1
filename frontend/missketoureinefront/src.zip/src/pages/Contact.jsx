import { useState } from 'react';
import { motion } from 'framer-motion';
import ContactForm from '../components/ContactForm';
import Notification from '../components/Notification';
import './Contact.css';

const Contact = () => {
  const [notification, setNotification] = useState({ isVisible: false, message: '', type: 'info' });

  const handleSubmit = async (formData) => {
    try {
      // Simuler l'envoi
      await new Promise(resolve => setTimeout(resolve, 1000));
      setNotification({
        isVisible: true,
        message: 'Votre message a été envoyé avec succès !',
        type: 'success'
      });
    } catch (error) {
      setNotification({
        isVisible: true,
        message: 'Erreur lors de l\'envoi du message',
        type: 'error'
      });
    }
  };

  return (
    <div className="contact-page">
      <Notification
        {...notification}
        onClose={() => setNotification({ ...notification, isVisible: false })}
      />

      <section className="contact-hero">
        <div className="container">
          <motion.h1
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
          >
            Contactez-nous
          </motion.h1>
          <motion.p
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.2 }}
          >
            Une question ? N'hésitez pas à nous contacter
          </motion.p>
        </div>
      </section>

      <section className="contact-content section">
        <div className="container">
          <div className="contact-grid">
            <motion.div
              className="contact-info"
              initial={{ opacity: 0, x: -30 }}
              animate={{ opacity: 1, x: 0 }}
            >
              <h2>Informations de contact</h2>
              <div className="info-item">
                <span className="info-icon">📧</span>
                <div>
                  <h3>Email</h3>
                  <p>contact@missandmister.bj</p>
                </div>
              </div>
              <div className="info-item">
                <span className="info-icon">📱</span>
                <div>
                  <h3>Téléphone</h3>
                  <p>+229 XX XX XX XX</p>
                </div>
              </div>
              <div className="info-item">
                <span className="info-icon">📍</span>
                <div>
                  <h3>Adresse</h3>
                  <p>Université du Bénin, Cotonou</p>
                </div>
              </div>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, x: 30 }}
              animate={{ opacity: 1, x: 0 }}
            >
              <ContactForm onSubmit={handleSubmit} />
            </motion.div>
          </div>
        </div>
      </section>
    </div>
  );
};

export default Contact;
