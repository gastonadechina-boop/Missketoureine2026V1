// Configuration de l'API
const API_BASE_URL = import.meta.env.VITE_API_URL || 'http://localhost:8000/api';

// Fonction helper pour les requêtes
const fetchAPI = async (endpoint, options = {}) => {
  const token = localStorage.getItem('authToken');
  
  const defaultHeaders = {
    'Content-Type': 'application/json',
    ...(token && { Authorization: `Bearer ${token}` }),
  };

  const config = {
    ...options,
    headers: {
      ...defaultHeaders,
      ...options.headers,
    },
  };

  try {
    const response = await fetch(`${API_BASE_URL}${endpoint}`, config);
    const data = await response.json();

    if (!response.ok) {
      throw new Error(data.message || 'Une erreur est survenue');
    }

    return data;
  } catch (error) {
    console.error('API Error:', error);
    throw error;
  }
};

// ===== AUTHENTIFICATION =====
export const authAPI = {
  // Inscription
  register: async (userData) => {
    return fetchAPI('/auth/register', {
      method: 'POST',
      body: JSON.stringify(userData),
    });
  },

  // Connexion
  login: async (credentials) => {
    return fetchAPI('/auth/login', {
      method: 'POST',
      body: JSON.stringify(credentials),
    });
  },

  // Déconnexion
  logout: async () => {
    return fetchAPI('/auth/logout', {
      method: 'POST',
    });
  },

  // Profil utilisateur
  getProfile: async () => {
    return fetchAPI('/auth/profile');
  },

  // Mise à jour du profil
  updateProfile: async (userData) => {
    return fetchAPI('/auth/profile', {
      method: 'PUT',
      body: JSON.stringify(userData),
    });
  },
};

// ===== CANDIDATS =====
export const candidatesAPI = {
  // Récupérer tous les candidats
  getAll: async (filters = {}) => {
    const queryParams = new URLSearchParams(filters).toString();
    return fetchAPI(`/candidates${queryParams ? `?${queryParams}` : ''}`);
  },

  // Récupérer un candidat par ID
  getById: async (id) => {
    return fetchAPI(`/candidates/${id}`);
  },

  // Récupérer les candidats par catégorie
  getByCategory: async (category) => {
    return fetchAPI(`/candidates?category=${category}`);
  },

  // Rechercher des candidats
  search: async (query) => {
    return fetchAPI(`/candidates/search?q=${encodeURIComponent(query)}`);
  },
};

// ===== VOTES =====
export const votesAPI = {
  // Voter pour un candidat
  vote: async (candidateId, paymentData) => {
    return fetchAPI('/votes', {
      method: 'POST',
      body: JSON.stringify({
        candidate_id: candidateId,
        ...paymentData,
      }),
    });
  },

  // Historique des votes de l'utilisateur
  getUserVotes: async () => {
    return fetchAPI('/votes/history');
  },

  // Vérifier si l'utilisateur peut voter
  canVote: async (candidateId) => {
    return fetchAPI(`/votes/can-vote/${candidateId}`);
  },

  // Statistiques de votes
  getStats: async () => {
    return fetchAPI('/votes/stats');
  },
};

// ===== RÉSULTATS =====
export const resultsAPI = {
  // Récupérer les résultats
  getResults: async () => {
    return fetchAPI('/results');
  },

  // Récupérer le classement
  getRanking: async (category = null) => {
    return fetchAPI(`/results/ranking${category ? `?category=${category}` : ''}`);
  },
};

// ===== GALERIE =====
export const galleryAPI = {
  // Récupérer toutes les photos/vidéos
  getAll: async () => {
    return fetchAPI('/gallery');
  },

  // Récupérer les médias par édition
  getByEdition: async (year) => {
    return fetchAPI(`/gallery/${year}`);
  },
};

// ===== CONTACT =====
export const contactAPI = {
  // Envoyer un message de contact
  sendMessage: async (messageData) => {
    return fetchAPI('/contact', {
      method: 'POST',
      body: JSON.stringify(messageData),
    });
  },
};

// ===== FAQ =====
export const faqAPI = {
  // Récupérer toutes les FAQs
  getAll: async () => {
    return fetchAPI('/faq');
  },
};

// ===== PAIEMENT =====
export const paymentAPI = {
  // Initier un paiement Mobile Money
  initiate: async (paymentData) => {
    return fetchAPI('/payment/initiate', {
      method: 'POST',
      body: JSON.stringify(paymentData),
    });
  },

  // Vérifier le statut d'un paiement
  checkStatus: async (transactionId) => {
    return fetchAPI(`/payment/status/${transactionId}`);
  },

  // Historique des paiements
  getHistory: async () => {
    return fetchAPI('/payment/history');
  },
};

// Export par défaut
export default {
  auth: authAPI,
  candidates: candidatesAPI,
  votes: votesAPI,
  results: resultsAPI,
  gallery: galleryAPI,
  contact: contactAPI,
  faq: faqAPI,
  payment: paymentAPI,
};
