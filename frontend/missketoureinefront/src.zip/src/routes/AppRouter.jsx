import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import Navbar from '../components/Navbar';
import Footer from '../components/Footer';
import Home from '../pages/Home';
import About from '../pages/About';
import Candidates from '../pages/Candidates';
import CandidateDetails from '../pages/CandidateDetails';
import Gallery from '../pages/Gallery';
import FAQ from '../pages/FAQ';
import Contact from '../pages/Contact';
import Login from '../pages/Login';
import Register from '../pages/Register';

// Admin imports
import AdminLogin from '../pages/admin/AdminLogin';
import AdminDashboard from '../pages/admin/AdminDashboard';
import AdminCandidates from '../pages/admin/AdminCandidates';
import AdminUsers from '../pages/admin/AdminUsers';
import AdminVotes from '../pages/admin/AdminVotes';
import AdminSettings from '../pages/admin/AdminSettings';
import AdminLayout from '../components/AdminLayout';

const AppRouter = () => {
  return (
    <Router>
      <Routes>
        {/* Public routes with navbar/footer */}
        <Route path="/" element={
          <div className="app-wrapper">
            <Navbar />
            <main className="main-content">
              <Home />
            </main>
            <Footer />
          </div>
        } />
        <Route path="/about" element={
          <div className="app-wrapper">
            <Navbar />
            <main className="main-content">
              <About />
            </main>
            <Footer />
          </div>
        } />
        <Route path="/candidates" element={
          <div className="app-wrapper">
            <Navbar />
            <main className="main-content">
              <Candidates />
            </main>
            <Footer />
          </div>
        } />
        <Route path="/candidates/:id" element={
          <div className="app-wrapper">
            <Navbar />
            <main className="main-content">
              <CandidateDetails />
            </main>
            <Footer />
          </div>
        } />
        <Route path="/gallery" element={
          <div className="app-wrapper">
            <Navbar />
            <main className="main-content">
              <Gallery />
            </main>
            <Footer />
          </div>
        } />
        <Route path="/faq" element={
          <div className="app-wrapper">
            <Navbar />
            <main className="main-content">
              <FAQ />
            </main>
            <Footer />
          </div>
        } />
        <Route path="/contact" element={
          <div className="app-wrapper">
            <Navbar />
            <main className="main-content">
              <Contact />
            </main>
            <Footer />
          </div>
        } />
        <Route path="/login" element={
          <div className="app-wrapper">
            <Navbar />
            <main className="main-content">
              <Login />
            </main>
            <Footer />
          </div>
        } />
        <Route path="/register" element={
          <div className="app-wrapper">
            <Navbar />
            <main className="main-content">
              <Register />
            </main>
            <Footer />
          </div>
        } />

        {/* Admin routes without navbar/footer */}
        <Route path="/admin/login" element={<AdminLogin />} />
        <Route path="/admin/dashboard" element={
          <AdminLayout>
            <AdminDashboard />
          </AdminLayout>
        } />
        <Route path="/admin/candidates" element={
          <AdminLayout>
            <AdminCandidates />
          </AdminLayout>
        } />
        <Route path="/admin/users" element={
          <AdminLayout>
            <AdminUsers />
          </AdminLayout>
        } />
        <Route path="/admin/votes" element={
          <AdminLayout>
            <AdminVotes />
          </AdminLayout>
        } />
        <Route path="/admin/settings" element={
          <AdminLayout>
            <AdminSettings />
          </AdminLayout>
        } />
      </Routes>
    </Router>
  );
};

export default AppRouter;
