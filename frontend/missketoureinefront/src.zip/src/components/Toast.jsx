import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import './Toast.css';

// Icônes pour les types de toast
const Icons = {
  success: (
    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
      <path d="M22 11.08V12C21.9988 14.1564 21.3005 16.2547 20.0093 17.9818C18.7182 19.7089 16.9033 20.9725 14.8354 21.5839C12.7674 22.1953 10.5573 22.1219 8.53447 21.3746C6.51168 20.6273 4.78465 19.2461 3.61096 17.4371C2.43727 15.628 1.87979 13.4881 2.02168 11.3363C2.16356 9.18455 2.99721 7.13631 4.39828 5.49706C5.79935 3.85781 7.69279 2.71537 9.79619 2.24013C11.8996 1.7649 14.1003 1.98232 16.07 2.85999" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
      <path d="M8 12L12 16L22 6" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
    </svg>
  ),
  error: (
    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
      <circle cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="2"/>
      <path d="M15 9L9 15M9 9L15 15" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
    </svg>
  ),
  warning: (
    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
      <path d="M12 9V11M12 15H12.01M10.29 3.86004L1.82002 18.05C1.64539 18.3401 1.55299 18.6708 1.55201 19.0075C1.55103 19.3442 1.64151 19.6753 1.81445 19.9663C1.98739 20.2573 2.23517 20.4973 2.52574 20.6607C2.81631 20.8241 3.1366 20.9046 3.46337 20.8934H20.5367C20.8635 20.9046 21.1838 20.8241 21.4743 20.6607C21.7649 20.4973 22.0127 20.2573 22.1856 19.9663C22.3586 19.6753 22.449 19.3442 22.4481 19.0075C22.4471 18.6708 22.3547 18.3401 22.1801 18.05L13.711 3.86004C13.5318 3.56614 13.2808 3.32319 12.9813 3.15551C12.6818 2.98783 12.3439 2.90215 12.0001 2.90215C11.6563 2.90215 11.3184 2.98783 11.0189 3.15551C10.7194 3.32319 10.4684 3.56614 10.2892 3.86004Z" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
    </svg>
  ),
  info: (
    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
      <circle cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="2"/>
      <path d="M12 16V12M12 8H12.01" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
    </svg>
  ),
  close: (
    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
      <path d="M18 6L6 18M6 6L18 18" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
    </svg>
  )
};

const Toast = ({ message, type = 'info', duration = 5000, onClose }) => {
  const [isVisible, setIsVisible] = useState(true);

  useEffect(() => {
    if (duration > 0) {
      const timer = setTimeout(() => {
        setIsVisible(false);
        setTimeout(onClose, 300); // Attendre la fin de l'animation
      }, duration);

      return () => clearTimeout(timer);
    }
  }, [duration, onClose]);

  const handleClose = () => {
    setIsVisible(false);
    setTimeout(onClose, 300);
  };

  return (
    <AnimatePresence>
      {isVisible && (
        <motion.div
          className={`toast toast-${type}`}
          initial={{ opacity: 0, x: 300, scale: 0.8 }}
          animate={{ opacity: 1, x: 0, scale: 1 }}
          exit={{ opacity: 0, x: 300, scale: 0.8 }}
          transition={{ type: 'spring', stiffness: 400, damping: 30 }}
        >
          <div className="toast-icon">
            {Icons[type]}
          </div>

          <div className="toast-content">
            <p className="toast-message">{message}</p>
          </div>

          <button
            className="toast-close"
            onClick={handleClose}
            aria-label="Fermer"
          >
            {Icons.close}
          </button>
        </motion.div>
      )}
    </AnimatePresence>
  );
};

// Gestionnaire global des toasts
let toastId = 0;
const toastContainer = [];

const ToastContainer = () => {
  const [, forceUpdate] = useState({});

  const showToast = (message, type = 'info', duration = 5000) => {
    const id = ++toastId;
    toastContainer.push({ id, message, type, duration });
    forceUpdate({});

    setTimeout(() => {
      const index = toastContainer.findIndex(t => t.id === id);
      if (index > -1) {
        toastContainer.splice(index, 1);
        forceUpdate({});
      }
    }, duration + 300);
  };

  const removeToast = (id) => {
    const index = toastContainer.findIndex(t => t.id === id);
    if (index > -1) {
      toastContainer.splice(index, 1);
      forceUpdate({});
    }
  };

  // Exposer la fonction showToast globalement
  if (typeof window !== 'undefined') {
    window.showToast = showToast;
  }

  return (
    <div className="toast-container">
      {toastContainer.map((toast) => (
        <Toast
          key={toast.id}
          message={toast.message}
          type={toast.type}
          duration={toast.duration}
          onClose={() => removeToast(toast.id)}
        />
      ))}
    </div>
  );
};

export { ToastContainer };
export default Toast;