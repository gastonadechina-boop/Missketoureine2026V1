import { useState, useEffect } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import { motion, AnimatePresence } from 'framer-motion';
import { ToastContainer } from './Toast';
import './AdminLayout.css';

const Icons = {
  dashboard: (
    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
      <rect x="3" y="3" width="7" height="7" rx="1" stroke="currentColor" strokeWidth="2"/>
      <rect x="14" y="3" width="7" height="7" rx="1" stroke="currentColor" strokeWidth="2"/>
      <rect x="14" y="14" width="7" height="7" rx="1" stroke="currentColor" strokeWidth="2"/>
      <rect x="3" y="14" width="7" height="7" rx="1" stroke="currentColor" strokeWidth="2"/>
    </svg>
  ),
  candidates: (
    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
      <path d="M16 7C16 9.20914 14.2091 11 12 11C9.79086 11 8 9.20914 8 7C8 4.79086 9.79086 3 12 3C14.2091 3 16 4.79086 16 7Z" stroke="currentColor" strokeWidth="2"/>
      <path d="M12 14C8.13401 14 5 17.134 5 21H19C19 17.134 15.866 14 12 14Z" stroke="currentColor" strokeWidth="2"/>
    </svg>
  ),
  users: (
    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
      <circle cx="9" cy="7" r="4" stroke="currentColor" strokeWidth="2"/>
      <path d="M2 21C2 17.134 5.13401 14 9 14C12.866 14 16 17.134 16 21" stroke="currentColor" strokeWidth="2" strokeLinecap="round"/>
      <path d="M19 8C20.6569 8 22 9.34315 22 11C22 12.6569 20.6569 14 19 14" stroke="currentColor" strokeWidth="2" strokeLinecap="round"/>
      <path d="M16 21C16 18.5 17.5 16.5 19 16" stroke="currentColor" strokeWidth="2" strokeLinecap="round"/>
    </svg>
  ),
  votes: (
    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
      <rect x="3" y="11" width="18" height="10" rx="2" stroke="currentColor" strokeWidth="2"/>
      <path d="M9 11V7C9 5.34315 10.3431 4 12 4C13.6569 4 15 5.34315 15 7V11" stroke="currentColor" strokeWidth="2" strokeLinecap="round"/>
      <circle cx="12" cy="16" r="1.5" fill="currentColor"/>
    </svg>
  ),
  settings: (
    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
      <circle cx="12" cy="12" r="3" stroke="currentColor" strokeWidth="2"/>
      <path d="M12 2v2M12 20v2M4.22 4.22l1.42 1.42M18.36 18.36l1.42 1.42M2 12h2M20 12h2M4.22 19.78l1.42-1.42M18.36 5.64l1.42-1.42" stroke="currentColor" strokeWidth="2" strokeLinecap="round"/>
    </svg>
  ),
  logout: (
    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
      <path d="M9 21H5C4.46957 21 3.96086 20.7893 3.58579 20.4142C3.21071 20.0391 3 19.5304 3 19V5C3 4.46957 3.21071 3.96086 3.58579 3.58579C3.96086 3.21071 4.46957 3 5 3H9" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
      <path d="M16 17L21 12L16 7" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
      <path d="M21 12H9" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
    </svg>
  ),
  menu: (
    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
      <path d="M3 12H21M3 6H21M3 18H21" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
    </svg>
  ),
  chevronLeft: (
    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
      <path d="M15 18L9 12L15 6" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
    </svg>
  ),
  chevronRight: (
    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
      <path d="M9 18L15 12L9 6" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
    </svg>
  ),
};

const SIDEBAR_FULL_WIDTH = 280;
const SIDEBAR_COLLAPSED_WIDTH = 72;
const MOBILE_BREAKPOINT = 1024;

const AdminLayout = ({ children }) => {
  const [sidebarOpen, setSidebarOpen] = useState(false);       // mobile uniquement
  const [sidebarCollapsed, setSidebarCollapsed] = useState(() => {
    const saved = localStorage.getItem('adminSidebarCollapsed');
    return saved ? JSON.parse(saved) : false;
  });
  const [isMobile, setIsMobile] = useState(window.innerWidth < MOBILE_BREAKPOINT);
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [isLoading, setIsLoading] = useState(true);

  const navigate = useNavigate();
  const location = useLocation();

  // Détecter le breakpoint mobile/desktop
  useEffect(() => {
    const handleResize = () => {
      const mobile = window.innerWidth < MOBILE_BREAKPOINT;
      setIsMobile(mobile);
      // Fermer l'overlay mobile quand on repasse en desktop
      if (!mobile) setSidebarOpen(false);
    };
    window.addEventListener('resize', handleResize);
    return () => window.removeEventListener('resize', handleResize);
  }, []);

  // Persister l'état collapsed
  useEffect(() => {
    localStorage.setItem('adminSidebarCollapsed', JSON.stringify(sidebarCollapsed));
  }, [sidebarCollapsed]);

  // Fermer le menu mobile lors d'un changement de page
  useEffect(() => {
    if (isMobile) setSidebarOpen(false);
  }, [location.pathname, isMobile]);

  // Vérification de l'authentification admin
  useEffect(() => {
    const token = localStorage.getItem('adminToken');
    if (!token) {
      navigate('/admin/login');
    } else {
      setIsAuthenticated(true);
    }
    setIsLoading(false);
  }, [navigate]);

  // Toggle unifié :
  // - Mobile  → ouvre/ferme l'overlay (sidebarOpen)
  // - Desktop → réduit/étend la sidebar (sidebarCollapsed)
  const handleToggleCollapse = () => {
    if (isMobile) {
      setSidebarOpen(prev => !prev);
    } else {
      setSidebarCollapsed(prev => !prev);
    }
  };

  const handleLogout = () => {
    localStorage.removeItem('adminToken');
    navigate('/admin/login');
  };

  const menuItems = [
    { path: '/admin/dashboard', label: 'Dashboard',   icon: Icons.dashboard   },
    { path: '/admin/candidates', label: 'Candidats',  icon: Icons.candidates  },
    { path: '/admin/users',      label: 'Utilisateurs',icon: Icons.users      },
    { path: '/admin/votes',      label: 'Votes',       icon: Icons.votes      },
    { path: '/admin/settings',   label: 'Paramètres',  icon: Icons.settings   },
  ];

  // Calculs des animations Framer Motion
  // Mobile  : sidebar toujours à width=280, slide sur l'axe X
  // Desktop : sidebar toujours à x=0,      anime la width
  const sidebarAnimate = isMobile
    ? { x: sidebarOpen ? 0 : -SIDEBAR_FULL_WIDTH, width: SIDEBAR_FULL_WIDTH }
    : { x: 0, width: sidebarCollapsed ? SIDEBAR_COLLAPSED_WIDTH : SIDEBAR_FULL_WIDTH };

  // Marge du contenu principal (desktop seulement)
  const mainMarginLeft = isMobile
    ? 0
    : sidebarCollapsed
      ? SIDEBAR_COLLAPSED_WIDTH
      : SIDEBAR_FULL_WIDTH;

  if (isLoading) {
    return (
      <div className="admin-loading">
        <div className="loading-spinner">
          <svg width="40" height="40" viewBox="0 0 24 24" fill="none">
            <circle cx="12" cy="12" r="10" stroke="#E5E7EB" strokeWidth="4"/>
            <path d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z" fill="#1E3A8A"/>
          </svg>
        </div>
        <p>Chargement de l'interface admin...</p>
      </div>
    );
  }

  if (!isAuthenticated) return null;

  return (
    <div className="admin-layout">

      {/* ── SIDEBAR ── */}
      <motion.aside
        className={`admin-sidebar ${sidebarCollapsed && !isMobile ? 'collapsed' : ''}`}
        animate={sidebarAnimate}
        initial={false}
        transition={{ type: 'spring', stiffness: 300, damping: 30 }}
      >
        {/* Header */}
        <div className="sidebar-header">
          <div className="sidebar-logo">
            {(!sidebarCollapsed || isMobile) && (
              <>
                <svg width="28" height="28" viewBox="0 0 24 24" fill="none">
                  <circle cx="12" cy="12" r="2" fill="#FFD700"/>
                  <circle cx="12" cy="12" r="5" stroke="#FFD700" strokeWidth="2" fill="none"/>
                  <circle cx="12" cy="12" r="9" stroke="#FFD700" strokeWidth="2" fill="none"/>
                </svg>
                <h2>Admin</h2>
              </>
            )}
            {sidebarCollapsed && !isMobile && (
              <svg width="22" height="22" viewBox="0 0 24 24" fill="none">
                <circle cx="12" cy="12" r="2" fill="#FFD700"/>
                <circle cx="12" cy="12" r="5" stroke="#FFD700" strokeWidth="2" fill="none"/>
              </svg>
            )}
          </div>

          {/* Bouton collapse (desktop uniquement dans le header) */}
          {!isMobile && (
            <button
              className="sidebar-collapse"
              onClick={handleToggleCollapse}
              title={sidebarCollapsed ? 'Développer' : 'Réduire'}
            >
              {sidebarCollapsed ? Icons.chevronRight : Icons.chevronLeft}
            </button>
          )}
        </div>

        {/* Navigation */}
        <nav className="sidebar-nav">
          {menuItems.map((item) => {
            const isActive = location.pathname === item.path;
            return (
              <motion.button
                key={item.path}
                className={`nav-item ${isActive ? 'active' : ''}`}
                onClick={() => navigate(item.path)}
                whileHover={{ scale: 1.02 }}
                whileTap={{ scale: 0.97 }}
                title={sidebarCollapsed && !isMobile ? item.label : ''}
              >
                {item.icon}
                {(!sidebarCollapsed || isMobile) && <span>{item.label}</span>}
              </motion.button>
            );
          })}
        </nav>

        {/* Footer */}
        <div className="sidebar-footer">
          <motion.button
            className="logout-btn"
            onClick={handleLogout}
            whileHover={{ scale: 1.04 }}
            whileTap={{ scale: 0.96 }}
            title={sidebarCollapsed && !isMobile ? 'Déconnexion' : ''}
          >
            {Icons.logout}
            {(!sidebarCollapsed || isMobile) && <span>Déconnexion</span>}
          </motion.button>
        </div>
      </motion.aside>

      {/* ── OVERLAY MOBILE ── */}
      {isMobile && sidebarOpen && (
        <motion.div
          className="sidebar-overlay"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          onClick={() => setSidebarOpen(false)}
        />
      )}

      {/* ── CONTENU PRINCIPAL ── */}
      <motion.div
        className="admin-main"
        animate={{ marginLeft: mainMarginLeft }}
        transition={{ type: 'spring', stiffness: 300, damping: 30 }}
      >
        {/* Topbar */}
        <header className="admin-topbar">
          <button
            className="menu-toggle"
            onClick={handleToggleCollapse}
            title={
              isMobile
                ? sidebarOpen ? 'Fermer le menu' : 'Ouvrir le menu'
                : sidebarCollapsed ? 'Développer' : 'Réduire'
            }
          >
            {isMobile
              ? Icons.menu
              : sidebarCollapsed ? Icons.chevronRight : Icons.chevronLeft}
          </button>

          <div className="topbar-title">
            <h1>
              {menuItems.find(item => item.path === location.pathname)?.label || 'Dashboard'}
            </h1>
          </div>

          <div className="topbar-actions">
            <div className="admin-info">
              <span>Admin Connecté</span>
            </div>
          </div>
        </header>

        {/* Page */}
        <main className="admin-content">
          {children}
        </main>
      </motion.div>

      <ToastContainer />
    </div>
  );
};

export default AdminLayout;