import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import logo from '../assets/logo.jpeg';
import './Footer.css';

const Footer = () => {
  const currentYear = new Date().getFullYear();

  const footerLinks = {
    navigation: [
      { path: '/', label: 'Accueil' },
      { path: '/about', label: 'À Propos' },
      { path: '/candidates', label: 'Candidats' },
      { path: '/gallery', label: 'Galerie' },
    ],
    support: [
      { path: '/faq', label: 'FAQ' },
      { path: '/contact', label: 'Contact' },
      { path: '/terms', label: 'Conditions d\'utilisation' },
      { path: '/privacy', label: 'Politique de confidentialité' },
    ],
  };

  const socialLinks = [
    { name: 'Facebook', icon: '📘', url: '#' },
    { name: 'Instagram', icon: '📷', url: '#' },
    { name: 'Twitter', icon: '🐦', url: '#' },
    { name: 'YouTube', icon: '📺', url: '#' },
  ];

  return (
    <footer className="footer">
      <div className="footer-container">
        {/* Section Logo et Description */}
        <motion.div
          className="footer-section footer-brand"
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.5 }}
        >
          <img src={logo} alt="Miss & Mister University Bénin" className="footer-logo" />
          <p className="footer-description">
            Le concours Miss & Mister University Bénin célèbre l'excellence, 
            l'élégance et le talent de la jeunesse universitaire béninoise.
          </p>
          <div className="footer-social">
            {socialLinks.map((social, index) => (
              <motion.a
                key={social.name}
                href={social.url}
                className="footer-social-link"
                target="_blank"
                rel="noopener noreferrer"
                whileHover={{ scale: 1.2, rotate: 5 }}
                whileTap={{ scale: 0.9 }}
                initial={{ opacity: 0, scale: 0 }}
                whileInView={{ opacity: 1, scale: 1 }}
                viewport={{ once: true }}
                transition={{ delay: index * 0.1 }}
                title={social.name}
              >
                <span>{social.icon}</span>
              </motion.a>
            ))}
          </div>
        </motion.div>

        {/* Section Navigation */}
        <motion.div
          className="footer-section"
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.5, delay: 0.1 }}
        >
          <h3 className="footer-title">Navigation</h3>
          <ul className="footer-links">
            {footerLinks.navigation.map((link) => (
              <li key={link.path}>
                <Link to={link.path} className="footer-link">
                  <span className="footer-link-icon">→</span>
                  {link.label}
                </Link>
              </li>
            ))}
          </ul>
        </motion.div>

        {/* Section Support */}
        <motion.div
          className="footer-section"
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.5, delay: 0.2 }}
        >
          <h3 className="footer-title">Support</h3>
          <ul className="footer-links">
            {footerLinks.support.map((link) => (
              <li key={link.path}>
                <Link to={link.path} className="footer-link">
                  <span className="footer-link-icon">→</span>
                  {link.label}
                </Link>
              </li>
            ))}
          </ul>
        </motion.div>

        {/* Section Contact */}
        <motion.div
          className="footer-section"
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.5, delay: 0.3 }}
        >
          <h3 className="footer-title">Contact</h3>
          <div className="footer-contact">
            <p>
              <span className="footer-contact-icon">📧</span>
              contact@missandmister.bj
            </p>
            <p>
              <span className="footer-contact-icon">📱</span>
              +229 XX XX XX XX
            </p>
            <p>
              <span className="footer-contact-icon">📍</span>
              Université du Bénin, Cotonou
            </p>
          </div>
        </motion.div>
      </div>

      {/* Barre de copyright */}
      <motion.div
        className="footer-bottom"
        initial={{ opacity: 0 }}
        whileInView={{ opacity: 1 }}
        viewport={{ once: true }}
        transition={{ duration: 0.5, delay: 0.4 }}
      >
        <div className="footer-bottom-container">
          <p className="footer-copyright">
            © {currentYear} Miss & Mister University Bénin. Tous droits réservés.
          </p>
          <p className="footer-credits">
            Développé avec <span className="footer-heart">❤️</span> par ANDROCRÉA
          </p>
        </div>
      </motion.div>

      {/* Effet de particules animées */}
      <div className="footer-particles">
        {[...Array(20)].map((_, i) => (
          <motion.div
            key={i}
            className="footer-particle"
            initial={{ opacity: 0, y: 0 }}
            animate={{
              opacity: [0, 1, 0],
              y: [-50, -200],
              x: [0, Math.random() * 100 - 50],
            }}
            transition={{
              duration: 3 + Math.random() * 2,
              repeat: Infinity,
              delay: Math.random() * 5,
            }}
            style={{
              left: `${Math.random() * 100}%`,
            }}
          />
        ))}
      </div>
    </footer>
  );
};

export default Footer;
