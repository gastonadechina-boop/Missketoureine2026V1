import { motion } from "framer-motion";
import { Link } from "react-router-dom";
import "./CandidateCard.css";

const CandidateCard = ({ candidate }) => {
  const {
    id,
    name,
    category, // 'Miss' ou 'Mister'
    university,
    photo,
    votes = 0,
    description,
  } = candidate;

  return (
    <motion.div
      className="candidate-card"
      initial={{ opacity: 0, scale: 0.9 }}
      whileInView={{ opacity: 1, scale: 1 }}
      viewport={{ once: true }}
      transition={{ duration: 0.5 }}
      whileHover={{ y: -10 }}
    >
      {/* Badge catégorie */}
      <div className={`candidate-badge ${category.toLowerCase()}`}>
        <span className="candidate-badge-icon">
          {category === "Miss" ? "👑" : "🤴"}
        </span>
        {category}
      </div>

      {/* Image du candidat */}
      <Link to={`/candidates/${id}`} className="candidate-image-link">
        <div className="candidate-image-wrapper">
          <motion.img
            src={photo || "/placeholder-candidate.jpg"}
            alt={name}
            className="candidate-image"
            whileHover={{ scale: 1.1 }}
            transition={{ duration: 0.3 }}
          />
          <div className="candidate-overlay">
            <motion.button
              className="candidate-view-btn"
              whileHover={{ scale: 1.1 }}
              whileTap={{ scale: 0.95 }}
            >
              Voir le profil
            </motion.button>
          </div>
        </div>
      </Link>

      {/* Informations du candidat */}
      <div className="candidate-info">
        <Link to={`/candidates/${id}`}>
          <motion.h3
            className="candidate-name"
            whileHover={{ color: "var(--secondary-gold)" }}
          >
            {name}
          </motion.h3>
        </Link>

        <p className="candidate-university">
          <span className="candidate-icon">🎓</span>
          {university}
        </p>

        {description && (
          <p className="candidate-description">
            {description.length > 80
              ? `${description.substring(0, 80)}...`
              : description}
          </p>
        )}

        {/* Statistiques de votes */}
        <div className="candidate-stats">
          <div className="candidate-votes">
            <span className="candidate-votes-icon">⭐</span>
            <span className="candidate-votes-count">
              {votes.toLocaleString()}
            </span>
            <span className="candidate-votes-label">votes</span>
          </div>
        </div>

        {/* Bouton de vote */}
        <Link to={`/candidates/${id}`}>
          <motion.button
            className="candidate-vote-btn"
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
          >
            <span className="candidate-vote-icon">💎</span>
            Voter maintenant
          </motion.button>
        </Link>
      </div>

      {/* Effet de brillance au survol */}
      <div className="candidate-shine"></div>
    </motion.div>
  );
};

export default CandidateCard;
